$(function(){
	$("#favList").load("favList.html"); 
});
