$(document).ready(function(){
  $("#listMakerLogo").animate({opacity: '1'}, 1100);
});
