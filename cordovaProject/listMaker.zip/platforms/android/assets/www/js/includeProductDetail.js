$(function(){
	$("#productDetail").load("productDetail.html"); 
});


