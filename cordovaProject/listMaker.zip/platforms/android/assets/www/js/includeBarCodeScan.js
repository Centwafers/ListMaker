$(function(){
	$("#barCodeScan").load("barCodeScan.html");
});

